from .main import apiAction, checkpointAction, dumpAction

def get_api_data(flag:str, env_var:dict={}, replacement_value:dict={}):
    apiIngester = apiAction()
    return apiIngester.get_api_data(flag, env_var, replacement_value)

def pull_checkpoint_data(glue_object, s3_bucket_name:str, checkpoint_file_path:str, checkpoint_start_date:str, aws_credentials:dict={}):
    checkpointObj = checkpointAction()
    return checkpointObj.pull_checkpoint_data(glue_object, s3_bucket_name, checkpoint_file_path, checkpoint_start_date, aws_credentials)

def update_original_checkpoint_file(glue_object:str, s3_bucket_name:str, checkpoint_file_path:str, new_checkpoint_record:list, checkpoint_initial_start_date:str, limit_rerun:int=5, aws_credentials:dict={}):
    checkpointObj = checkpointAction()
    checkpointObj.update_original_checkpoint_file(glue_object, s3_bucket_name, checkpoint_file_path, new_checkpoint_record, checkpoint_initial_start_date, limit_rerun, aws_credentials)

def checkpoint_get_missing_dates(checkpoint_data:dict, StaticTz:str="Asia/Jakarta"):
    checkpointObj = checkpointAction()
    return checkpointObj.checkpoint_get_missing_dates(checkpoint_data, StaticTz)

def checkpoint_get_dates_based_on_flag(checkpoint_data:dict, flag:str):
    checkpointObj = checkpointAction()
    return checkpointObj.checkpoint_get_dates_based_on_flag(checkpoint_data, flag)

def checkpoint_get_date_flag_status(checkpoint_data:dict, target_date:str):
    checkpointObj = checkpointAction()
    return checkpointObj.checkpoint_get_date_flag_status(checkpoint_data, target_date)

def create_config_vars(environment:str, s3_bucket_name:str, database_name:str, etl_id_val:str, tempdir:str, api_response:dict):
    dumpObj = dumpAction()
    return dumpObj.create_config_vars(environment, s3_bucket_name, database_name, etl_id_val, tempdir, api_response)

def dump_data(sqlObject:str, glueObject:str, dataframe, dump_configs:dict, aws_credentials:dict={}):
    dumpObj = dumpAction()
    dumpObj.dump_data(sqlObject, glueObject, dataframe, dump_configs, aws_credentials)