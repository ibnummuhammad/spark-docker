import unittest
from staging.apipygest.__init__ import *
import os
import json
import re
import pytz
import datetime

class testIngestor(unittest.TestCase):

	os.chdir(os.getcwd()+'/staging/apipygest/test/')
	with open('dummy_checkpoint_data.json', 'r') as f:
		__cp_data = json.load(f)

	with open('dummy_get_api_config.json','r') as f:
		configs = json.load(f)
		__api_params = configs['api_params']
		res_vals = configs['res_vals']

	date_regex = '(\d{4})[/.-](\d{2})[/.-](\d{2})$'

	def test_get_api_data_get(self):
		val_get = get_api_data(self.__api_params['get']['flag'])
		self.assertEqual(type(val_get), dict, f'GET Method | Return value of get_api_data() function must be in {dict} dtype!')
		for res_k in self.res_vals:
			self.assertIn(res_k, val_get.keys(), f'GET Method | {res_k} not found in get_api_data() response value!')
	
	def test_get_api_data_post(self):
		val_post = get_api_data(
					self.__api_params['post']['flag'],
					self.__api_params['post']['env_var'],
					self.__api_params['post']['replacement_value']
			  		)
		self.assertEqual(type(val_post), dict, f'POST Method | Return value of get_api_data() function must be in {dict} dtype!')
		for res_k in self.res_vals:
			self.assertIn(res_k, val_post.keys(), f'POST Method | {res_k} not found in get_api_data() response value!')

	def test_check_data_format_from_checkpoint_get_missing_dates(self):
		missing_dates = checkpoint_get_missing_dates(checkpoint_data=self.__cp_data, StaticTz='Asia/Jakarta')
		self.assertEqual(type(missing_dates), list, f'Return value of checkpoint_get_missing_dates() function must be in {list} type!')

		for missing_date in missing_dates:
			mat = re.match(self.date_regex, missing_date)
			flag  = True if mat is not None else False
			self.assertEqual(flag, True, 'The data from checkpoint_get_missing_dates() must be in YYYY-MM-DD format!')

		JakartaTz = pytz.timezone('Asia/Jakarta')
		temp_dates = [datetime.datetime.strptime(missing_date, '%Y-%m-%d').astimezone(JakartaTz) for missing_date in missing_dates]
		sort_flag = True if temp_dates == sorted(temp_dates, reverse=True) else False
		self.assertEqual(sort_flag, True, 'The data from checkpoint_get_missing_dates() must be in descending order!')

	def test_check_data_format_from_checkpoint_get_dates_based_on_flag(self):
		complete_flag = checkpoint_get_dates_based_on_flag(checkpoint_data=self.__cp_data, flag='complete')
		self.assertEqual(type(complete_flag), list, f'Return value of get_dates_based_on_flag() must be in {list} type!')
		self.assertEqual(len(complete_flag), 2, 'The total data from get_dates_based_on_flag() is wrong!')
		for complete_date in complete_flag:
			mat = re.match(self.date_regex, complete_date)
			flag  = True if mat is not None else False
			self.assertEqual(flag, True, 'The data from get_dates_based_on_flag() must be in YYYY-MM-DD format!')
		self.assertEqual(complete_flag, ['2023-04-11', '2023-03-23'], 'The data from get_dates_based_on_flag() is wrong!')

	def test_checkpoint_get_date_flag_status(self):
		flag_stat = checkpoint_get_date_flag_status(checkpoint_data=self.__cp_data, target_date='2023-04-11')
		self.assertEqual(type(flag_stat), str, f'Return value of get_date_flag_status() must be in {str} type!')
		self.assertEqual(flag_stat, 'complete', 'The data from get_date_flag_status() is wrong!')

	def test_create_config_vars(self):
		etl_id_ts = datetime.datetime.now()
		tempDir = 's3://tiptip-datalake-stg-ke8f/glue'
		database_name = 'data_warehouse'
		config_vars = create_config_vars(
							environment='local',
							s3_bucket_name='staging-bucket_name',
							database_name=database_name,
							etl_id_val=etl_id_ts.strftime('%Y-%m-%d-%H'),
							tempdir=tempDir,
							api_response=get_api_data(self.__api_params['get']['flag'])
						)

		self.assertEqual(type(config_vars), dict, f'The return value from create_config_vars() must be in {dict} type!')
	
		for dump_key in ['s3_bucket_name', 's3_path_prefix', 's3_path', 'redshift_dbname', 'redshift_table_name', 'redshift_tempdir']:
			self.assertIn(dump_key, config_vars.keys(), f'{dump_key} key not found in the first part of return value '
		 				'from create_config_vars() response value!')
			self.assertEqual(type(config_vars[dump_key]), str, f'The value of {dump_key} key from the first part return '
		    			f'value of create_config_vars() must be in {str} type!')

if __name__ == '__main__':
    unittest.main()