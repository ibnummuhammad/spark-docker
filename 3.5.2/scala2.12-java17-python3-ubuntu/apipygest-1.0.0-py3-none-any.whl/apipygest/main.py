import datetime
import pytz
import requests
import boto3
import botocore
from botocore.config import Config
import re
import yaml
import os
import json
from urllib.parse import quote
import time
import pandas as pd
import redshift_connector


class apiAction:
    def __init__(self) -> None:
        self.__target_env_var = list()
        self.__api_config_meta = dict()
        self.__config_var = ['api', 'method', 'auth', 'params', 'headers', 'payload', 'additionalBodyScript']

    def __yaml_constructor(self, loader, node):
        value = loader.construct_scalar(node)
        for group in re.compile(r'.*?\${(.*?)}.*?').findall(value):
            if group in self.__target_env_var:
                value = value.replace(f'${{{group}}}', os.environ.get(group))
        return value

    def __getpath(self, source_dict: dict, prepath: list = [], result: list = []):
        for k, v in source_dict.items():
            path = prepath + [k]
            if '${' in v:
                result.append(path)
            elif hasattr(v, 'items'):
                p = self.__getpath(v, path)
                if p is not None:
                    continue
        return result

    def get_api_data(self, flag: str, env_var: dict = {}, replacement_value: dict = {}, next_token: dict = {}):
        """
        This function is used to retrieve data from a source in the form of an API.
        All parameter values will be refered to the apis_config_for_etl.yaml file and
        external API body file.

        Parameters
        ----------
        flag : str, mandatory
            This parameter value is used to filter a pack of configurations on the
            apis_config_for_etl.yaml file as a basedline to get the data from the
            specific API
        env_var : dict, optional
            This parameter value is mandatory if the flag's configuration in 
            apis_config_for_etl.yaml has custom variable(s) with format ${var_name}
        replacement_value : dict, optional
            This parameter will be used only if there is a need to override the value(s)
            contained in the external API body file
        next_token : dict, optional
            {<'params'|'headers'>: {<tokenKey>:<tokenValue>}}

        Returns
        -------
        dict
            status_code(int)
                API code status response
            status_reason(str)
                API reason response
            elapsed_time(datetime.timedelta)
                total time required to pull data from API
            api_url(str)
                API URL being used
            api_params(dict)
                API parameters being used
            api_hit_time(str)
                The time when API is hit in UTC+0 datetime format
            content(str)
                API payload response
            target_redshift_schema(str)
                Redshift schema
            target_redshift_table_name(str)
                Redshift table name
        """

        if env_var:
            tempKey = []
            for var_key in env_var.keys():
                os.environ[var_key] = env_var[var_key]
                tempKey.append(var_key)
            self.__target_env_var = tempKey.copy()
            yaml.add_implicit_resolver('!pathex', re.compile(r'.*?\${(.*?)}.*?'))
            yaml.add_constructor('!pathex', self.__yaml_constructor)

        with open('apis_config_for_etl.yaml', 'r') as yf:
            list_configs = yaml.load(yf, Loader=yaml.FullLoader)['targets']
        api_conf = next(item for item in list_configs['tables'] if item['flag'] == flag)
        undefined_params = self.__getpath(api_conf)
        for path_param in undefined_params:
            conf_temp = api_conf
            for key in path_param:
                if key == path_param[-1]:
                    del conf_temp[key]
                else:
                    conf_temp = conf_temp[key]

        self.__api_config_meta['schema_name'] = api_conf['schema']
        self.__api_config_meta['table_name'] = api_conf['name']

        for var_key in self.__config_var:
            empty_condt = '' if var_key in ['api', 'method', 'payload'] else {}
            self.__api_config_meta[var_key] = api_conf['meta'][var_key] if var_key in api_conf['meta'].keys() else empty_condt

        if next_token:
            api_part = list(next_token.keys())[0]
            if api_part in ['params', 'headers']:
                key_params = list(next_token[api_part].keys())[0]
                self.__api_config_meta[api_part][key_params] = next_token[api_part][key_params]

        if self.__api_config_meta['method'].lower() == 'get':
            hit_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            resp = requests.get(
                url=self.__api_config_meta['api'],
                params=self.__api_config_meta['params'],
                headers=self.__api_config_meta['headers'],
                auth=(self.__api_config_meta['auth']['username'], self.__api_config_meta['auth']['password']) if self.__api_config_meta['auth']['type'] == 'basic' else ()
            )
        elif self.__api_config_meta['method'].lower() == 'post':
            if self.__api_config_meta['payload'].split('.')[-1] == 'js':
                with open(self.__api_config_meta['payload'], 'r') as f:
                    body_payload = quote(f.read())
                if 'additionalBodyScript' in self.__api_config_meta.keys():
                    for adbs in self.__api_config_meta['additionalBodyScript'].keys():
                        body_payload = self.__api_config_meta['additionalBodyScript'][adbs] + body_payload if adbs == 'prefix' else body_payload + self.__api_config_meta['additionalBodyScript'][adbs]
                if replacement_value:
                    for rep_key in replacement_value.keys():
                        body_payload = body_payload.replace(rep_key, replacement_value[rep_key])
                hit_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                resp = requests.post(
                    url=self.__api_config_meta['api'],
                    data=body_payload,
                    params=self.__api_config_meta['params'],
                    headers=self.__api_config_meta['headers'],
                    auth=(self.__api_config_meta['auth']['username'], self.__api_config_meta['auth']['password']) if self.__api_config_meta['auth']['type'] == 'basic' else ()
                )
            elif self.__api_config_meta['payload'].split('.')[-1] == 'json':
                with open(self.__api_config_meta['payload'], 'r') as f:
                    body_payload = json.load(f)
                if replacement_value:
                    for rep_key in replacement_value.keys():
                        body_payload[rep_key] = replacement_value[rep_key]
                hit_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                resp = requests.post(
                    url=self.__api_config_meta['api'],
                    json=body_payload,
                    params=self.__api_config_meta['params'],
                    headers=self.__api_config_meta['headers'],
                    auth=(self.__api_config_meta['auth']['username'], self.__api_config_meta['auth']['password']) if self.__api_config_meta['auth']['type'] == 'basic' else ()
                )
            else:
                raise TypeError(f'{datetime.datetime.now()} | get_api_data() | '
                                'API body file type is unknown. The acceptable file can only be JSON or Javascript format.')
        else:
            raise ValueError(f'{datetime.datetime.now()} | get_api_data() | '
                             'Method value is unknown. The value can only be GET or POST.')

        response = {
            'status_code': resp.status_code,
            'status_reason': resp.reason,
            'elapsed_time': resp.elapsed,
            'api_url': resp.url,
            'api_params': self.__api_config_meta['params'],
            'api_hit_time': hit_time,
            'content': resp.content.decode('utf-8'),
            'target_redshift_schema': self.__api_config_meta['schema_name'],
            'target_redshift_table_name': self.__api_config_meta['table_name']
        }

        return response


class checkpointAction:
    def __init__(self) -> None:
        self.__s3_bucket_name = str()
        self.__checkpoint_file_path = str()
        self.__glue_object = str()
        self.__aws_credentials = dict()
        self.__checkpoint_keyword = str()
        self.__checkpoint_start_date = str()
        self.__default_checkpoint_content = dict()
        self.__updated_checkpoint_data = dict()

        self.__logger = str()

        self.__config = Config(retries=dict(max_attempts=10))
        self.__session = str()
        self.__conn_opt = dict()
        self.__fmt_opt = dict()

    def __checkpoint_file_availability(self):
        """
        This function is used to check the availability of checkpoint file.

        Parameters
        ----------
        N/A

        Returns
        -------
        int
        """
        if self.__aws_credentials:
            client = self.__session.resource('s3', region_name="ap-southeast-1", config=self.__config)
        else:
            client = boto3.resource('s3')

        try:
            client.Object(self.__s3_bucket_name, self.__checkpoint_file_path).load()
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == '404':
                self.__logger.info(f'{datetime.datetime.now()} | checkpoint_file_availability() | ' +
                                   self.__checkpoint_file_path.split('/')[-1] + ' file not found in ' +
                                   self.__s3_bucket_name + '/' + self.__checkpoint_file_path.split('/')[0])
                return 404
            else:
                self.__logger.info(f'{datetime.datetime.now()} | checkpoint_file_availability() | There is an error: ' +
                                   e.response['Error']['Message'])
                raise ValueError(e.response['Error']['Message'])
        else:
            self.__logger.info(f'{datetime.datetime.now()} | checkpoint_file_availability() | ' +
                               self.__checkpoint_file_path.split('/')[-1] + ' file found.')
            return 1

    def __create_new_checkpoint_file(self):
        """
        This function is used to create new checkpoint file if not available on S3 bucket.

        Parameters
        ----------
        N/A

        Returns
        -------
        None
        """
        if self.__aws_credentials:
            client = self.__session.client('s3', region_name="ap-southeast-1", config=self.__config)
        else:
            client = boto3.client('s3')

        self.__default_checkpoint_content = {
            'checkpoint': {
                self.__checkpoint_keyword: [
                    {
                        'date': self.__checkpoint_start_date,
                        'meta': {
                            'rerun': 0,
                            'flag': 'rerun',
                            'history': []
                        }
                    }
                ]
            }
        }

        try:
            client.put_object(Body=json.dumps(self.__default_checkpoint_content),
                              Bucket=self.__s3_bucket_name,
                              Key=self.__checkpoint_file_path)
        except botocore.exceptions.ClientError as e:
            raise ValueError(e.response['Error']['Message'])
        else:
            self.__logger.info(f'{datetime.datetime.now()} | create_new_checkpoint_file() | File ' +
                               self.__checkpoint_file_path.split('/')[-1] + ' has finished initializing.')

    def pull_checkpoint_data(self, glue_object: str, s3_bucket_name: str, checkpoint_file_path: str, checkpoint_start_date: str, aws_credentials: dict = {}):
        """
        This function is used to pull the content of the checkpoint file targeted.

        Parameters
        ----------
        glue_object : awsglue.context.GlueContext, mandatory
            This parameter value is a glueContext object that will be used to get
            the content from S3 bucket
        s3_bucket_name : str, mandatory
            This parameter value is the S3 bucket name used to store
            the checkpoint file
        checkpoint_file_path : str, mandatory
            This parameter value is the file path of the checkpoint file
            including the file name
        checkpoint_start_date : str, mandatory
            This parameter value is the start date of the checkpoint file
            with format YYYY-MM-DD used for checkpoint file creation if
            not available on S3 bucket
        aws_credentials : dict, optional
            This parameter value is only used when this module is running
            in a local environment to create the latest AWS session so
            that all boto3 functions can run properly and this parameter
            must have 3 keys named aws_access_key_id, aws_secret_access_key
            and aws_session_token

        Returns
        -------
        dict
        """
        self.__s3_bucket_name = s3_bucket_name
        self.__checkpoint_file_path = checkpoint_file_path
        self.__glue_object = glue_object
        self.__checkpoint_start_date = checkpoint_start_date
        self.__checkpoint_keyword = checkpoint_file_path.split("/")[-1].split(".")[0]
        self.__logger = self.__glue_object.get_logger()
        self.__aws_credentials = aws_credentials

        if aws_credentials:
            self.__session = boto3.Session(
                aws_access_key_id=self.__aws_credentials['aws_access_key_id'],
                aws_secret_access_key=self.__aws_credentials['aws_secret_access_key'],
                aws_session_token=self.__aws_credentials['aws_session_token'],
            )

        file_availability_status = self.__checkpoint_file_availability()

        if file_availability_status == 1:
            pass
        else:
            self.__create_new_checkpoint_file()
            time.sleep(5)

        self.__conn_opt['paths'] = [f's3://{self.__s3_bucket_name}/{self.__checkpoint_file_path}']
        self.__fmt_opt['withHeader'] = True
        cp_raw = self.__glue_object.create_dynamic_frame.from_options(
            connection_type='s3',
            connection_options=self.__conn_opt,
            format='json',
            format_options=self.__fmt_opt
        )
        return json.loads(cp_raw.toDF().toJSON().first())

    def __update_current_checkpoint_data(self, updated_checkpoint_data: dict, new_checkpoint_record: list, limit_rerun: int = 5):
        """
        This function is used to update checkpoint record per date.

        Parameters
        ----------
        updated_checkpoint_data : dict, mandatory
            This parameter value is the return value of pull_checkpoint_data()
            function
        new_checkpoint_record : list, mandatory [event_date, flag_status, history]
            This parameter value is a list that contains event_date, flag_status
            and history sequentially where event_date is used to filter specific
            checkpoint record that want to be updated and flag_status is to set
            the flag parameter on the meta object of the checkpoint record target
            then history contains all of information needed that you want to save
            for a checkpoint record
        limit_rerun : int, mandatory
            This parameter value is used to limit a checkpoint record if it reaches
            the limit then the flag value of that record will be changed to failed
            state

        Returns
        -------
        dict
            full format of checkpoint data with updated record
        """
        if type(new_checkpoint_record) != list:
            raise ValueError(f'{datetime.datetime.now()} | update_current_checkpoint_data() | '
                             'new_checkpoint_record must be in list format!')
        else:
            if len(new_checkpoint_record) != 3:
                raise ValueError(f'{datetime.datetime.now()} | update_current_checkpoint_data() | '
                                 'new_checkpoint_record must consist of 3 values [event_date, flag_status, history]!')
            else:
                regex = re.compile('[0-9]{4}\-[0-9]{2}\-[0-9]{2}')
                if not re.match(regex, new_checkpoint_record[0]):
                    raise ValueError(f'{datetime.datetime.now()} | update_current_checkpoint_data() | '
                                     '1st index of new_checkpoint_record value must be in YYYY-MM-DD format!')

        self.__updated_checkpoint_data = updated_checkpoint_data
        cp_key = list(self.__updated_checkpoint_data['checkpoint'].keys())[0]

        tmp = {}
        item_idx = next(
            (
                index for (index, item) in enumerate(self.__updated_checkpoint_data['checkpoint'][cp_key]) if item['date'] == new_checkpoint_record[0]
            ), 'null'
        )
        if item_idx == 'null':
            tmp['date'] = new_checkpoint_record[0]
            tmp['meta'] = {}
            tmp['meta']['rerun'] = 1 if new_checkpoint_record[1] == 'rerun' else 0
            tmp['meta']['flag'] = new_checkpoint_record[1]
            tmp['meta']['history'] = []
            tmp['meta']['history'].append(new_checkpoint_record[2])
            self.__updated_checkpoint_data['checkpoint'][cp_key].append(tmp)
        else:
            '''
            You can set any flag for this checkpoint, for example:
            - complete : optional | won't be executed again in the next run - this flag means the API response is 200 and the data has been dumped into the datalake
            - rerun : mandatory | will be executed again in the next run - this flag means the API didn't return a success response or not 200
            - failed : automatic | won't be executed again in the next run - this flag means the maximum rerun value has reached the limit which is 5
            - empty : optional | won't be executed again in the next run - this flag means the API response is 200 but the data is empty
            - limit : optional | will be executed again in the next run - this flag means the API is unable to fetch data due to API hit time limitation issue
            - etc.....
            '''
            self.__updated_checkpoint_data['checkpoint'][cp_key][item_idx]['meta']['history'].append(new_checkpoint_record[2])
            if new_checkpoint_record[1] != 'rerun':
                self.__updated_checkpoint_data['checkpoint'][cp_key][item_idx]['meta']['flag'] = new_checkpoint_record[1]
            else:
                self.__updated_checkpoint_data['checkpoint'][cp_key][item_idx]['meta']['rerun'] += 1
                if self.__updated_checkpoint_data['checkpoint'][cp_key][item_idx]['meta']['rerun'] >= int(limit_rerun):
                    self.__updated_checkpoint_data['checkpoint'][cp_key][item_idx]['meta']['flag'] = 'failed'
                else:
                    self.__updated_checkpoint_data['checkpoint'][cp_key][item_idx]['meta']['flag'] = new_checkpoint_record[1]

        return self.__updated_checkpoint_data

    def update_original_checkpoint_file(self, glue_object: str, s3_bucket_name: str, checkpoint_file_path: str, new_checkpoint_record: list, checkpoint_initial_start_date: str, limit_rerun: int = 5, aws_credentials: dict = {}):
        """
        This function is used to update checkpoint file on the S3 bucket

        Parameters
        ----------
        glue_object : awsglue.context.GlueContext, mandatory
            This parameter value is a glueContext object that will be used to get
            the content from S3 bucket
        s3_bucket_name : str, mandatory
            This parameter value is defined the S3 bucket name that is used to
            store the checkpoint file
        checkpoint_file_path : str, mandatory
            This parameter gives the information the path of checkpoint file
            stored in S3 bucket
        new_checkpoint_record : list, mandatory [event_date, flag_status, history]
            This parameter value is a list that contains event_date, flag_status
            and history sequentially where event_date is used to filter specific
            checkpoint record that want to be updated and flag_status is to set
            the flag parameter on the meta object of the checkpoint record target
            then history contains all of information needed that you want to save
            for a checkpoint record
        checkpoint_initial_start_date: str, mandatory
            This parameter value is the start date of the checkpoint file
            with format YYYY-MM-DD used for checkpoint file creation if
            not available on S3 bucket
        limit_rerun : int, mandatory
            This parameter value is used to limit a checkpoint record if it reaches
            the limit then the flag value of that record will be changed to failed
            state
        aws_credentials : dict, optional
            This parameter value is only used when this module is running
            in a local environment to create the latest AWS session so
            that all boto3 functions can run properly and this parameter
            must have 3 keys named aws_access_key_id, aws_secret_access_key
            and aws_session_token

        Returns
        -------
        None
        """
        current_checkpoint = self.pull_checkpoint_data(glue_object, s3_bucket_name, checkpoint_file_path, checkpoint_initial_start_date, aws_credentials)
        latest_checkpoint = self.__update_current_checkpoint_data(current_checkpoint, new_checkpoint_record, limit_rerun)
        self.__aws_credentials = aws_credentials

        if self.__aws_credentials:
            self.__session = boto3.Session(
                aws_access_key_id=self.__aws_credentials['aws_access_key_id'],
                aws_secret_access_key=self.__aws_credentials['aws_secret_access_key'],
                aws_session_token=self.__aws_credentials['aws_session_token'],
            )
            client = self.__session.client('s3', region_name="ap-southeast-1", config=self.__config)
        else:
            client = boto3.client('s3')

        try:
            client.put_object(Body=json.dumps(latest_checkpoint),
                              Bucket=s3_bucket_name,
                              Key=checkpoint_file_path)
            time.sleep(3)
        except botocore.exceptions.ClientError as e:
            raise ValueError(f'{datetime.datetime.now()} | update_current_checkpoint_data() | ' +
                             e.response['Error']['Message'])

    def checkpoint_get_missing_dates(self, checkpoint_data: dict, StaticTz: str = "Asia/Jakarta"):
        """
        This function is used to find dates that are not in the checkpoint file starting
        from the initial date (this date is defined in the __create_new_checkpoint_file()
        function if the checkpoint file was not available before) to the current date
        minus 1 day

        Parameters
        ----------
        checkpoint_data : dict, mandatory
            This parameter value is in the format of the return value
            from checkpointAction().pull_checkpoint_data()
        StaticTz : str, optional
            This parameter value is used to set the default timezone and
            will use Jakarta time by default if not set

        Returns
        -------
        list
            list of dates in YYYY-MM-DD format
        """
        cp_key = list(checkpoint_data['checkpoint'].keys())[0]
        JakartaTz = pytz.timezone(StaticTz)
        current_datetime = datetime.datetime.now(JakartaTz)
        current_hour, current_minute = current_datetime.hour, current_datetime.minute

        checkpoint_dates = [datetime.datetime.strptime(i["date"], "%Y-%m-%d").astimezone(JakartaTz).replace(hour=current_hour, minute=current_minute) for i in checkpoint_data['checkpoint'][cp_key]]
        checkpoint_dates.sort(reverse=False)
        diff_checkpoint_dates = set(checkpoint_dates[0] + datetime.timedelta(x) for x in range((current_datetime - checkpoint_dates[0]).days))
        missing = sorted(diff_checkpoint_dates - set(checkpoint_dates))
        missing = [i.strftime("%Y-%m-%d") for i in missing]
        missing.sort(reverse=True)
        return missing

    def checkpoint_get_dates_based_on_flag(self, checkpoint_data: dict, flag: str):
        """
        This function is used to find dates in the checkpoint file that
        have a flag value on their meta object that matches with the
        flag parameter

        Parameters
        ----------
        checkpoint_data : dict, mandatory
            This parameter value is in the format of the return value
            from checkpointAction().pull_checkpoint_data()
        flag : str, mandatory
            This parameter value is used to filter all of the dates that
            have this value on their meta object
            [rerun | limit | empty | complete | failed | etc...]

        Returns
        -------
        list
            list of dates in YYYY-MM-DD format
        """
        cp_key = list(checkpoint_data['checkpoint'].keys())[0]
        flag_item = [item['date'] for (index, item) in enumerate(checkpoint_data['checkpoint'][cp_key]) if item["meta"]["flag"] == flag]
        flag_item.sort(reverse=True)
        return flag_item

    def checkpoint_get_date_flag_status(self, checkpoint_data: dict, target_date: str):
        """
        This function is used to check the status flag on a certain date based
        on the target_date parameter

        Parameters
        ----------
        checkpoint_data : dict, mandatory
            This parameter value is in the format of the return value
            from checkpointAction().pull_checkpoint_data()
        target_date : str, mandatory
            This parameter value is in YYYY-MM-DD format

        Returns
        -------
        str
            flag value of the target_date, will return "None" if the target_date
            is not available on the checkpoint file
        """
        cp_key = list(checkpoint_data['checkpoint'].keys())[0]
        rerun_item = next((item for (index, item) in enumerate(checkpoint_data['checkpoint'][cp_key]) if item["date"] == target_date), "None")
        try:
            return rerun_item["meta"]["flag"]
        except:
            return "None"


class dumpAction:
    def __init__(self) -> None:
        self.__sqlObject = str()
        self.__glueObject = str()
        self.__rawDataframe = pd.DataFrame
        self.__apply_mapping = str()

        self.__logger = str()

        self.__dump_configs = dict()

        self.__aws_credentials = dict()
        self.__session = boto3.Session
        self.__config = Config(retries=dict(max_attempts=10))

    def __mapping_data(self):
        spark_df = self.__sqlObject.createDataFrame(self.__rawDataframe)
        dynamic_frame = DynamicFrame.fromDF(spark_df, glue_ctx=self.__glueObject, name="df")
        self.__apply_mapping = ApplyMapping.apply(
            frame=dynamic_frame,
            mappings=[
                ('payload', 'string', 'payload', 'string'),
                ('params', 'string', 'params', 'string'),
                ('run_ts', 'string', 'run_ts', 'timestamp'),
                ('etl_id', 'string', 'etl_id', 'string'),
                ('etl_id_ts', 'string', 'etl_id_ts', 'timestamp'),
                ('etl_id_partition', 'string', 'etl_id_partition', 'long')
            ]
        )
        self.__logger.info(f'{datetime.datetime.now()} | mapping_data() | mapping data process completed')
        self.__apply_mapping.printSchema()
        self.__apply_mapping.toDF().show(10)

    def __dump_data_into_s3(self):
        if self.__aws_credentials:
            client = self.__session.resource('s3', region_name="ap-southeast-1", config=self.__config)
        else:
            client = boto3.resource('s3')

        client.Bucket(self.__dump_configs['s3_bucket_name']).objects.filter(Prefix=self.__dump_configs['s3_path_prefix']).delete()
        self.__glueObject.write_dynamic_frame.from_options(
            frame=self.__apply_mapping,
            connection_type='s3',
            connection_options={'path': self.__dump_configs['s3_path']},
            format='parquet',
            transformation_ctx='datasink'
        )

        self.__logger.info(f'{datetime.datetime.now()} | dump_data_into_s3() | '
                           f'data successfully dumped into {self.__dump_configs["s3_path"]}')

    def __dump_data_into_redshift(self):

        redshift_tmp_table_name = f"{self.__dump_configs['redshift_table_name']}_temp"

        create_main_table_query = f" \
            DROP TABLE IF EXISTS {redshift_tmp_table_name}; \
            CREATE TABLE {redshift_tmp_table_name} AS SELECT * FROM {self.__dump_configs['redshift_table_name']}; \
            DROP TABLE IF EXISTS {self.__dump_configs['redshift_table_name']}; \
            CREATE TABLE IF NOT EXISTS {self.__dump_configs['redshift_table_name']} ("\
                "payload SUPER,"\
                "params SUPER,"\
                "run_ts TIMESTAMP,"\
                "etl_id VARCHAR(256),"\
                "etl_id_ts TIMESTAMP,"\
                "etl_id_partition BIGINT"\
            ");"

        drop_temp_query = f" \
            INSERT INTO {self.__dump_configs['redshift_table_name']} SELECT * FROM {redshift_tmp_table_name}; \
            DROP TABLE IF EXISTS {redshift_tmp_table_name} \
        ;"

        self.__glueObject.write_dynamic_frame.from_jdbc_conf(
            frame=self.__apply_mapping, catalog_connection=self.__dump_configs['redshift_dbname'],
            connection_options={
                'preactions': create_main_table_query,
                'dbtable': self.__dump_configs['redshift_table_name'],
                'database': self.__dump_configs['redshift_dbname'],
                'postactions': drop_temp_query,
            },
            redshift_tmp_dir=self.__dump_configs['redshift_tempdir']
        )

        self.__logger.info(f'{datetime.datetime.now()} | dump_data_into_redshift() | '
                           f'Record successfully inserted into {self.__dump_configs["redshift_table_name"]} table')

    def create_config_vars(self, environment: str, s3_bucket_name: str, database_name: str, etl_id_val: str, tempdir: str, api_response: dict):
        s3_path_prefix = environment + '/' + api_response['target_redshift_table_name'] + '/' + etl_id_val
        s3_path = 's3://' + s3_bucket_name + '/' + s3_path_prefix
        dump_configs = {
            's3_bucket_name': s3_bucket_name,
            's3_path_prefix': s3_path_prefix,
            's3_path': s3_path,
            'redshift_dbname': database_name,
            'redshift_table_name': api_response['target_redshift_schema'] + '.' + api_response['target_redshift_table_name'],
            'redshift_tempdir': tempdir
        }

        return dump_configs

    def dump_data(self, sqlObject: str, glueObject: str, dataframe: pd.DataFrame, dump_configs: dict, aws_credentials: dict = {}):
        """
        This function is used to find dates in the checkpoint file that
        have a flag value on their meta object that matches with the
        flag parameter

        Parameters
        ----------
        sqlObject : pyspark.sql.SQLContext, mandatory
            This parameter value is a SQLContext object
        glueObject : awsglue.context.GlueContext, mandatory
            This parameter value is a GlueContext object
        dataframe : pandas.DataFrame, mandatory
            This parameter value is data that ready to be loaded into redshift
            and S3 in pandas dataframe format which must have the following
            columns [payload, params, etl_id, etl_id_ts, etl_id_partition]
        s3_configs : dict, mandatory
            This parameter value is the value generated by create_config_vars()
            function
        redshift_configs : dict, mandatory
            This parameter value is the value generated by create_config_vars()
            function
        aws_credentials : dict, optional
            This parameter value is only used when this module is running
            in a local environment to create the latest AWS session so
            that all boto3 functions can run properly and this parameter
            must have 3 keys named aws_access_key_id, aws_secret_access_key
            and aws_session_token

        Returns
        -------
        None
        """
        self.__sqlObject = sqlObject
        self.__glueObject = glueObject
        self.__dump_configs = dump_configs
        self.__rawDataframe = dataframe
        self.__logger = self.__glueObject.get_logger()
        self.__aws_credentials = aws_credentials

        self.__logger.info(f'{datetime.datetime.now()} | dump_data() | start dump data into S3 and RedShift...')

        for clmn in ['payload', 'params', 'run_ts', 'etl_id', 'etl_id_ts', 'etl_id_partition']:
            if clmn not in list(dataframe.columns):
                raise KeyError(f'{datetime.datetime.now()} | dump_data() | '
                               f'{clmn} is not found in Column Names on Pandas Dataframe.')

        if self.__aws_credentials:
            self.__session = boto3.Session(
                aws_access_key_id=self.__aws_credentials['aws_access_key_id'],
                aws_secret_access_key=self.__aws_credentials['aws_secret_access_key'],
                aws_session_token=self.__aws_credentials['aws_session_token'],
            )

        self.__mapping_data()
        self.__dump_data_into_s3()
        self.__dump_data_into_redshift()


class IngestionPipeline:
    def __init__(self):
        import json
        import logging
        from datetime import datetime

        self.args_: dict = {}
        self.aws: dict = json.loads(self.args_.aws)
        self.aws_token: dict = json.loads(self.args_.aws_token)
        self.environment: str = self.args_.environment
        self.job_partition: int = (
            None if self.args_.job_partition == "" else int(self.args_.job_partition)
        )
        self.redshift: str = json.loads(self.args_.redshift)
        self.table: dict = json.loads(self.args_.table)

        logging.basicConfig(
            level=logging._nameToLevel[self.table["meta"]["job"]["log_level"]]
        )
        self.logger = logging.getLogger()

        self.data_interval_start: datetime = datetime.strptime(
            self.args_.data_interval_start, "%Y-%m-%d %H:%M:%S"
        )
        self.data_interval_end: datetime = datetime.strptime(
            self.args_.data_interval_end, "%Y-%m-%d %H:%M:%S"
        )

        self.redshift_partition: dict = {}
        self.redshift_connection = str()

    def run(self, main):
        import sys

        try:
            main()
        except Exception as e:
            error_message = f"ERROR MESSAGE: {str(e)}"
            self.logger.error(error_message)
            sys.exit(str(e))

        self.logger.info("Ingestion pipeline succeed!")

    @property
    def redshift_connection(self) -> redshift_connector.connect:
        return self._redshift_connection

    @redshift_connection.setter
    def redshift_connection(self, _) -> None:
        redshift_connection = redshift_connector.connect(
            host=self.redshift["host"],
            database=self.redshift["database"],
            user=self.redshift["user"],
            password=self.redshift["password"],
        )

        redshift_connection.autocommit = True

        self._redshift_connection = redshift_connection

    @property
    def args_(self) -> dict:
        return self._args

    @args_.setter
    def args_(self, _):
        import argparse

        parser = argparse.ArgumentParser()
        parser.add_argument("--aws")
        parser.add_argument("--aws_token")
        parser.add_argument("--data_interval_end")
        parser.add_argument("--data_interval_start")
        parser.add_argument("--environment")
        parser.add_argument("--job_partition")
        parser.add_argument("--redshift")
        parser.add_argument("--table")
        args_ = parser.parse_args()

        self._args = args_

    def remove_duplicate(self, insert_method: str = None, query: str = None) -> None:
        with self.redshift_connection.cursor() as cursor:
            cursor.execute(
                f"""
                SELECT
                    1
                FROM
                    information_schema.tables
                WHERE
                    table_schema = '{self.redshift["schema"]}'
                    AND table_name = '{self.table["name"]}'
                """
            )
            result: tuple = cursor.fetchall()

            if len(result) > 0:
                if insert_method == "overwrite-partition":
                    query = f"""
                        DELETE FROM
                            {self.redshift["schema"]}.{self.table["name"]}
                        WHERE
                            {self.redshift["schema"]}.{self.table["name"]}.etl_id = '{self.redshift_partition["etl_id"]}';
                    """  # noqa: E501
                elif insert_method == "truncate-table":
                    query = f"""
                        TRUNCATE TABLE
                            {self.redshift["schema"]}.{self.table["name"]}
                    """
                elif insert_method == "drop-table":
                    query = f"""
                        DROP TABLE IF EXISTS
                            {self.redshift["schema"]}.{self.table["name"]};
                    """

                cursor.execute(query)

    @property
    def redshift_partition(self) -> dict:
        return self._partition

    @redshift_partition.setter
    def redshift_partition(self, _) -> None:
        import datetime
        import pytz

        run_ts = datetime.datetime.now(pytz.timezone("Asia/Jakarta"))

        self._partition = {
            "etl_id": self.data_interval_end.strftime("%Y-%m-%d-%H"),
            "etl_id_partition": int(self.data_interval_end.timestamp()),
            "etl_id_ts": self.data_interval_end,
            "run_ts": run_ts,
        }

    def _load_to_s3(self) -> None:
        import boto3
        from botocore.config import Config

        s3_filename = f"{self.table['name']}_{self.redshift_partition['run_ts'].strftime('%Y_%m_%d_%H_%M_%S')}"  # noqa: E501

        session = boto3.Session()
        config = Config(retries=dict(max_attempts=10))
        s3 = session.resource(
            "s3",
            aws_access_key_id=self.aws_token["aws_access_key_id"],
            aws_secret_access_key=self.aws_token["aws_secret_access_key"],
            aws_session_token=self.aws_token["aws_session_token"],
            config=config,
        )
        self.df.to_parquet(f"/tmp/{s3_filename}.parquet")
        s3.meta.client.upload_file(
            f"/tmp/{s3_filename}.parquet",
            self.aws["s3"]["bucket"],
            "{environment}/{job_name}/{redshift_partition}/{s3_filename}.parquet".format(  # noqa: E501
                environment=self.environment,
                job_name=self.table["name"],
                redshift_partition=self.redshift_partition["etl_id"],
                s3_filename=s3_filename,
            ),
        )

    def _load_to_redshift(self) -> None:
        import json

        import boto3

        session = boto3.Session()
        s3 = session.resource(
            "s3",
            aws_access_key_id=self.aws_token["aws_access_key_id"],
            aws_secret_access_key=self.aws_token["aws_secret_access_key"],
            aws_session_token=self.aws_token["aws_session_token"],
        )

        # Params
        temp = self.df.copy()
        filename_params = f"{self.table['name']}_params_tmp.json"
        fileloc_params = f"/tmp/{filename_params}"
        temp.params = temp.params.apply(json.loads)
        temp["params"].to_json(fileloc_params, orient="records", lines=True)
        s3.meta.client.upload_file(
            f"/tmp/{filename_params}",
            self.aws["s3"]["bucket"],
            f"tmp/{filename_params}",
        )

        # Payload
        temp = self.df.copy()
        filename_payload = f"{self.table['name']}_payload_tmp.json"
        fileloc_payload = f"/tmp/{filename_payload}"
        temp.payload = temp.payload.apply(json.loads)
        temp["payload"].to_json(fileloc_payload, orient="records", lines=True)
        s3.meta.client.upload_file(
            f"/tmp/{filename_payload}",
            self.aws["s3"]["bucket"],
            f"tmp/{filename_payload}",
        )

        query_drop_tmp_params = f"DROP TABLE IF EXISTS {self.redshift['schema']}.{self.table['name']}_params_tmp;"  # noqa: E501
        query_drop_tmp_payload = f"DROP TABLE IF EXISTS {self.redshift['schema']}.{self.table['name']}_payload_tmp;"  # noqa: E501
        query_drop_tmp = f"DROP TABLE IF EXISTS {self.redshift['schema']}.{self.table['name']}_tmp;"  # noqa: E501

        query_create_table_params = f"""
            CREATE TABLE IF NOT EXISTS {self.redshift['schema']}.{self.table['name']}_params_tmp (
                params SUPER
            );
        """  # noqa: E501
        query_create_table_payload = f"""
            CREATE TABLE IF NOT EXISTS {self.redshift['schema']}.{self.table['name']}_payload_tmp (
                payload SUPER
            );
        """  # noqa: E501
        query_create_table_tmp = f"""
            CREATE TABLE IF NOT EXISTS {self.redshift['schema']}.{self.table['name']}_tmp (
                params SUPER,
                payload SUPER
            );
        """  # noqa: E501
        query_create_table = f"""
            CREATE TABLE IF NOT EXISTS {self.redshift['schema']}.{self.table['name']} (
                params SUPER,
                payload SUPER,
                etl_id VARCHAR(256),
                etl_id_ts TIMESTAMP,
                etl_id_partition BIGINT,
                run_ts TIMESTAMP
            );
        """  # noqa: E501

        query_copy_file_params = f"""
            COPY
                {self.redshift['schema']}.{self.table['name']}_params_tmp
            FROM
                's3://{self.aws["s3"]["bucket"]}/tmp/{filename_params}'
            REGION
                'ap-southeast-1'
            IAM_ROLE
                '{self.aws["iam"]["role"]}'
            FORMAT JSON
                'noshred';
        """
        query_copy_file_payload = f"""
            COPY
                {self.redshift['schema']}.{self.table['name']}_payload_tmp
            FROM
                's3://{self.aws["s3"]["bucket"]}/tmp/{filename_payload}'
            REGION
                'ap-southeast-1'
            IAM_ROLE
                '{self.aws["iam"]["role"]}'
            FORMAT JSON
                'noshred';
        """
        query_copy_file = f"""
            INSERT INTO
                {self.redshift['schema']}.{self.table['name']}_tmp
            (
                SELECT
                    params,
                    payload
                FROM
                    {self.redshift['schema']}.{self.table['name']}_params_tmp,
                    {self.redshift['schema']}.{self.table['name']}_payload_tmp
            );
        """

        query_add_etl_id = f"""
            ALTER TABLE
                {self.redshift['schema']}.{self.table['name']}_tmp
            ADD COLUMN
                etl_id VARCHAR(256)
            DEFAULT
                '{self.redshift_partition["etl_id"]}';
        """
        query_add_etl_id_ts = f"""
            ALTER TABLE
                {self.redshift['schema']}.{self.table['name']}_tmp
            ADD COLUMN
                etl_id_ts TIMESTAMP
            DEFAULT
                '{self.redshift_partition["etl_id_ts"]}';
        """
        query_add_etl_id_partition = f"""
            ALTER TABLE
                {self.redshift['schema']}.{self.table['name']}_tmp
            ADD COLUMN
                etl_id_partition BIGINT
            DEFAULT
                {self.redshift_partition["etl_id_partition"]};
        """
        query_add_run_ts = f"""
            ALTER TABLE
                {self.redshift['schema']}.{self.table['name']}_tmp
            ADD COLUMN
                run_ts TIMESTAMP
            DEFAULT
                '{self.redshift_partition["run_ts"]}';
        """
        query_copy_to_main_table = f"""
            INSERT INTO
                {self.redshift['schema']}.{self.table['name']}
            (
                SELECT
                    DISTINCT params,
                    payload,
                    etl_id,
                    etl_id_ts,
                    etl_id_partition,
                    run_ts
                FROM
                    {self.redshift['schema']}.{self.table['name']}_tmp
            );
        """

        with self.redshift_connection.cursor() as cursor:
            cursor.execute(query_drop_tmp_payload)
            cursor.execute(query_drop_tmp_params)
            cursor.execute(query_drop_tmp)

            cursor.execute(query_create_table_payload)
            cursor.execute(query_create_table_params)
            cursor.execute(query_create_table_tmp)
            cursor.execute(query_create_table)

            cursor.execute(query_copy_file_payload)
            cursor.execute(query_copy_file_params)
            cursor.execute(query_copy_file)

            cursor.execute(query_add_etl_id)
            cursor.execute(query_add_etl_id_ts)
            cursor.execute(query_add_etl_id_partition)
            cursor.execute(query_add_run_ts)
            cursor.execute(query_copy_to_main_table)

            cursor.execute(query_drop_tmp_payload)
            cursor.execute(query_drop_tmp_params)
            cursor.execute(query_drop_tmp)

        obj = s3.Object(
            self.aws["s3"]["bucket"],
            f"tmp/{filename_payload}",
        )
        obj.delete()
        obj = s3.Object(
            self.aws["s3"]["bucket"],
            f"tmp/{filename_params}",
        )
        obj.delete()

        self.logger.info(
            f"Done storing data to redshift in table {self.redshift['schema']}.{self.table['name']}"  # noqa: E501
        )
        self.logger.info(f"-> inserting data = {len(self.df)} rows")
        self.logger.info(f"-> table etl_id = {self.redshift_partition['etl_id']}")
        self.logger.info(f"-> table run_ts = {self.redshift_partition['run_ts']}")

    def load_data(self, df: pd.DataFrame) -> None:
        self.df = df

        self._load_to_s3()
        self._load_to_redshift()
